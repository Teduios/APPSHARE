//
//  UIBarButtonItem+MJ.h
//  传智微博
//
//  Created by teacher on 14-6-7.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (MJ)
/**
 *  通过图片创建item
 *
 *  @param imageName     图片
 *  @param highImageName 高亮图片
 *  @param action    点击后调用的方法
 */
+ (UIBarButtonItem *)itemWithImageName:(NSString *)imageName highImageName:(NSString *)highImageName Target:(id)target action:(SEL)action;
@end
