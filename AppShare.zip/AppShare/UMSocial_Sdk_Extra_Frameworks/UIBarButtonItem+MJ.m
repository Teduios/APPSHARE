//
//  UIBarButtonItem+MJ.m
//  传智微博
//
//  Created by teacher on 14-6-7.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "UIBarButtonItem+MJ.h"
#import "UIImage+MJ.h"
#import "UIView+MJ.h"
#import "UIView+Extension.h"

@implementation UIBarButtonItem (MJ)

+ (UIBarButtonItem *)itemWithImageName:(NSString *)imageName highImageName:(NSString *)highImageName Target:(id)target action:(SEL)action
{
    //创建按钮
    UIButton *button = [[UIButton alloc]init];
    button.frame = CGRectMake(0, 0, 35, 35);
    //设置背景图片
    [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    //设置高亮图片
    [button setBackgroundImage:[UIImage imageNamed:highImageName] forState:UIControlStateHighlighted];
    //设置监听事件
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *barItem = [[UIBarButtonItem alloc]initWithCustomView:button];
    
    return barItem;
    
}
@end
