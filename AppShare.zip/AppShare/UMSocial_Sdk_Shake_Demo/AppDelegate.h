//
//  AppDelegate.h
//  UMSocial_Sdk_Shake_Demo
//
//  Created by yeahugo on 13-12-13.
//  Copyright (c) 2013年 yeahugo. All rights reserved.
//

#import <UIKit/UIKit.h>
#define UmengAppkey @"5211818556240bc9ee01db2f"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
