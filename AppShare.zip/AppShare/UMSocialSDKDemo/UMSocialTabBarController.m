//
//  UMSocialTabViewController.m
//  SocialSDK
//
//  Created by yeahugo on 13-1-25.
//  Copyright (c) 2013年 Umeng. All rights reserved.
//

#import "UMSocialTabBarController.h"
#import "UMSocialLoginViewController.h"
#import "UMSocialSnsViewController.h"

#define wxdColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

@implementation UMSocialTabBarController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    UMSocialSnsViewController *moneyTableView = [[UMSocialSnsViewController alloc]init];
    [self addOnceChildVc:moneyTableView title:nil imageName:@"UMS_share@2x" selectedImageName:nil];
    
    UMSocialLoginViewController *walletView = [[UMSocialLoginViewController alloc]init];
    [self addOnceChildVc:walletView title:@"授权" imageName:@"UMS_mutilBar@2x" selectedImageName:nil];

}

- (void)addOnceChildVc:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    childVc.title = title;
    childVc.tabBarItem.title = title;
    
    childVc.view.backgroundColor = wxdColor(211, 211, 211);
//    childVc.view.backgroundColor = [UIColor whiteColor];
    childVc.tabBarItem.image = [UIImage imageNamed:imageName];
    childVc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImageName];
    
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:childVc];
    [self addChildViewController:nav];
}



@end
