 //
//  UMSocialSnsViewController.m
//  SocialSDK
//
//  Created by yeahugo on 13-5-19.
//  Copyright (c) 2013年 Umeng. All rights reserved.
//

#import "UMSocialSnsViewController.h"
#import "AppDelegate.h"
#import "UIView+Extension.h"
#import "UMSocialScreenShoter.h"

#define kTagShareEdit 101
#define kTagSharePost 102

@interface UMSocialSnsViewController ()
@property (weak, nonatomic) IBOutlet UITextView *shareTextView;
@property (strong, nonatomic) UIImageView *imageView;
@property(nonatomic,strong) UIButton *button;
@end

@implementation UMSocialSnsViewController
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]init];
    }
    return _imageView;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

//下面设置点击分享列表之后，可以直接分享
-(BOOL)isDirectShareInIconActionSheet
{
    return YES;
}

/*
 注意分享到新浪微博我们使用新浪微博SSO授权，你需要在xcode工程设置url scheme，并重写AppDelegate中的`- (BOOL)application openURL sourceApplication`方法，详细见文档。否则不能跳转回来原来的app。
*/

/*
 在自定义分享样式中，根据点击不同的点击来处理不同的的动作
*/
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex + 1 >= actionSheet.numberOfButtons ) {
        return;
    }
    NSLog(@"click button index is %d",buttonIndex);
    //分享编辑页面的接口,snsName可以换成你想要的任意平台，例如UMShareToSina,UMShareToWechatTimeline
    NSString *snsName = [[UMSocialSnsPlatformManager sharedInstance].allSnsValuesArray objectAtIndex:buttonIndex];
    NSString *shareText = @"晒👂，轻松分享美丽时刻";
    UIImage *shareImage = [UIImage imageNamed:@"UMS_social_demo"];
    
    if (actionSheet.tag == kTagShareEdit) {
        //设置分享内容，和回调对象
        [[UMSocialControllerService defaultControllerService] setShareText:shareText shareImage:shareImage socialUIDelegate:self];
        UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:snsName];
        snsPlatform.snsClickHandler(self,[UMSocialControllerService defaultControllerService],YES);
    } else if (actionSheet.tag == kTagSharePost){
        [[UMSocialDataService defaultDataService] postSNSWithTypes:@[snsName] content:shareText image:shareImage location:nil urlResource:nil presentedController:self completion:^(UMSocialResponseEntity * response){
            if (response.responseCode == UMSResponseCodeSuccess) {
                UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"成功" message:@"分享成功" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
                [alertView show];
            } else if(response.responseCode != UMSResponseCodeCancel) {
                UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"失败" message:@"分享失败" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
                [alertView show];
            }
        }];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"分享";
    self.tabBarItem.image = [UIImage imageNamed:@"UMS_share"];
    
    //设置导航栏按钮及触发事件（包含分享的发送及清除）
    [self setupNavBar];
    //添加图片按钮的设置及触发事件
    [self addImageButton];
}
//设置导航栏属性
- (void)setupNavBar
{
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"清除" style:UIBarButtonItemStyleDone target:self action:@selector(cancel)];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(sendImageAndText)];
}
#pragma mark -- 发送分享和清空内容
//发送分享
- (void)sendImageAndText
{
    NSString *shareText = self.shareTextView.text;//分享内嵌文字
    UIImage *shareImage = self.imageView.image;//分享内嵌图片
    //    UIImage *shareImage = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"UMS_social_demo" ofType:@"png"]];
    //调用快速分享接口
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:UmengAppkey
                                      shareText:shareText
                                     shareImage:shareImage
                                shareToSnsNames:@[UMShareToSina,UMShareToWechatSession,UMShareToWechatTimeline,UMShareToQQ,UMShareToTencent,UMShareToQzone,UMShareToRenren,UMShareToDouban]
                                       delegate:self
     //UMShareToFacebook,UMShareToTwitter
     ];
}
//清除
- (void)cancel
{
    self.shareTextView.text = nil;
    self.imageView.image = nil;
    [self.button setBackgroundImage:[UIImage imageNamed:@"compose_pic_add_highlighted"] forState:UIControlStateNormal];
}

#pragma mark -- 添加、删除图片按钮的触发方法
- (void)addImageButton
{
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(10, 230, 150, 150)];
     self.button = button;
    [button setBackgroundImage:[UIImage imageNamed:@"compose_pic_add_highlighted@2x"]  forState:UIControlStateNormal];
    
    //点击按钮的触发事件
    [self.button addTarget:self action:@selector(addPhoto) forControlEvents:UIControlEventTouchUpInside];
    //设置图片长按状态的触发事件
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(buttonLongPress)];
    longPress.minimumPressDuration = 1;//定义按的时间为一秒
   [self.button addGestureRecognizer:longPress];
    
    [self.view addSubview:self.button];
}
//添加图片的按钮
- (void)addPhoto
{
    //创建提示框。（preferredStyle：设置提示框的样式为UIAlertControllerStyleActionSheet）
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"请选择图片源"
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    //style:UIAlertActionStyleDefault（字体样式颜色）
    [alert addAction:[UIAlertAction actionWithTitle:@"相册"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action)
                      {
                          UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
                          ipc.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                          ipc.delegate = self;
                          [self presentViewController:ipc animated:YES completion:nil];
                      }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照"
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
                                                UIImagePickerController *ipc = [[UIImagePickerController alloc] init];
                                                ipc.sourceType = UIImagePickerControllerSourceTypeCamera;
                                                ipc.delegate = self;
                                                [self presentViewController:ipc animated:YES completion:nil];
                                            }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消"
                                              style:UIAlertActionStyleCancel
                                            handler:^(UIAlertAction *action) {
                                                return;
                                            }]];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}

//长按按钮删除图片
- (void)buttonLongPress
{
     self.imageView.image = nil;
    if (self.imageView != nil) {
        [self.button setBackgroundImage:[UIImage imageNamed:@"compose_pic_add_highlighted@2x"] forState:UIControlStateNormal];
    }else{
        return;
    }
    
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    // 1.销毁选图片的控制器
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    // 2.取得选中的图片
    self.imageView.image = info[UIImagePickerControllerOriginalImage];

    [self.button setBackgroundImage:self.imageView.image  forState:UIControlStateNormal];
}


-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    /*
     如果要弹出的分享列表支持不同方向，需要在这里设置一下重新布局
     如果当前UIViewController有UINavigationController,则用self.navigationController.view，否则用self.view
     */
    UIView * iconActionSheet = [self.tabBarController.view viewWithTag:kTagSocialIconActionSheet];
    
    [iconActionSheet setNeedsDisplay];
    UIView * shakeView = [self.tabBarController.view viewWithTag:kTagSocialShakeView];
    [shakeView setNeedsDisplay];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.shareTextView resignFirstResponder];
}


@end
